### Hexlet tests and linter status:
[![Actions Status](https://github.com/ross0maha/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/ross0maha/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/2e3053157b86113f589e/maintainability)](https://codeclimate.com/github/ross0maha/python-project-49/maintainability)

```
  ____            _              ____                           
 | __ ) _ __ __ _(_)_ __        / ___| __ _ _ __ ___   ___  ___ 
 |  _ \| '__/ _` | | '_ \ _____| |  _ / _` | '_ ` _ \ / _ \/ __|
 | |_) | | | (_| | | | | |_____| |_| | (_| | | | | | |  __/\__ \
 |____/|_|  \__,_|_|_| |_|      \____|\__,_|_| |_| |_|\___||___/
```

#### My first project in the He\}\{let school.


### Brain-Even game.

Demo, how install and play:
[![asciicast](https://asciinema.org/a/0lxZs0uvlVgKnmgtOgYBo2NrS.svg)](https://asciinema.org/a/0lxZs0uvlVgKnmgtOgYBo2NrS)
