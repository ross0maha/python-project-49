EVEN_PROMT = 'Answer "yes" if the number is even, otherwise answer "no".'
CALC_PROMT = 'What is the result of the expression?'
GCD_PROMT = 'Find the greatest common divisor of given numbers.'
PROGRESSION_PROMT = 'What number is missing in the progression?'
PRIME_PROMT = 'Answer "yes" if given number is prime. ' \
              'Otherwise answer "no".'
AMOUNT_OF_ROUNDS = 3
OPERATORS = ['+', '-', '*']
